const { Pool } = require('@neondatabase/serverless');

const connectionString = process.env.DATABASE_URL || process.env.POSTGRES_URL || process.env.POSTGRES_PRISMA_URL;
if (!connectionString) {
  console.warn('DATABASE_URL is not set. Set it in .env for local development or in Vercel Environment Variables.');
}

const pool = new Pool({ connectionString });

function convertPlaceholders(sql) {
  let i = 0;
  let out = '';
  let inSingle = false;
  let inDouble = false;
  for (let p = 0; p < sql.length; p++) {
    const ch = sql[p];
    const next = sql[p + 1];
    if (ch === "'" && !inDouble) {
      if (inSingle && next === "'") { out += "''"; p++; continue; }
      inSingle = !inSingle;
      out += ch;
      continue;
    }
    if (ch === '"' && !inSingle) { inDouble = !inDouble; out += ch; continue; }
    if (ch === '?' && !inSingle && !inDouble) { i++; out += `$${i}`; }
    else out += ch;
  }
  return out;
}

function normalizeSql(sql) {
  return sql
    .replace(/INSERT\s+OR\s+IGNORE\s+INTO/gi, 'INSERT INTO')
    .replace(/VALUES\s*\(([^;]*?)\)\s*$/gis, (m) => m)
    .replace(/\bcurrent_stage\s*=\s*"(MD|HRM|Section|CHRO|Closed)"/g, "current_stage='$1'")
    .replace(/\bstatus\s*=\s*"([A-Za-z]+)"/g, "status='$1'")
    .replace(/"([^"]+)"/g, "'$1'");
}

function prepare(sql) {
  const normalized = normalizeSql(sql);
  const converted = convertPlaceholders(normalized);
  return {
    async get(...params) {
      const result = await pool.query(converted, params);
      return result.rows[0];
    },
    async all(...params) {
      const result = await pool.query(converted, params);
      return result.rows;
    },
    async run(...params) {
      let query = converted;
      if (/^\s*INSERT\s+/i.test(query) && !/\bON\s+CONFLICT\b/i.test(query)) {
        query += ' ON CONFLICT DO NOTHING';
      }
      if (/^\s*INSERT\s+/i.test(query) && !/\bRETURNING\b/i.test(query)) {
        query += ' RETURNING id';
      }
      const result = await pool.query(query, params);
      return { changes: result.rowCount, lastInsertRowid: result.rows[0]?.id };
    }
  };
}

async function exec(sql) {
  const statements = sql.split(/;\s*(?=CREATE|ALTER|INSERT|UPDATE|DELETE)/i).map(s => s.trim()).filter(Boolean);
  for (const statement of statements) await pool.query(statement);
}

async function close() { await pool.end(); }

module.exports = { db: { prepare, exec }, pool, close };
