document.addEventListener('click',e=>{
 const btn=e.target.closest('[data-confirm]');
 if(btn&&!confirm(btn.dataset.confirm))e.preventDefault();
});
document.querySelectorAll('[data-other-select]').forEach(select=>{
 const target=document.querySelector(select.dataset.otherSelect);
 const toggle=()=>{if(target)target.style.display=select.options[select.selectedIndex]?.text==='Other'?'block':'none'};
 select.addEventListener('change',toggle);toggle();
});

if ('serviceWorker' in navigator) { window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {})); }
