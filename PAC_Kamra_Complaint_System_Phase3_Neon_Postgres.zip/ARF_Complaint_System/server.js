const express = require('express');
const session = require('cookie-session');
const helmet = require('helmet');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const path = require('path');
const { db } = require('./db');
const { initializeDatabase } = require('./init-db');

const app = express();
if (process.env.NODE_ENV === 'production') app.set('trust proxy', 1);
const PORT = process.env.PORT || 3000;

app.set('view engine','ejs');
app.set('views',path.join(__dirname,'views'));
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.urlencoded({extended:true}));
app.use(express.json());
app.use(express.static(path.join(__dirname,'public')));
app.use(session({
  name: 'pac_session',
  secret: process.env.SESSION_SECRET || 'change-this-secret-in-production',
  httpOnly: true,
  sameSite: 'lax',
  secure: process.env.NODE_ENV === 'production',
  maxAge: 60 * 60 * 1000
}));

function now() { return new Date().toISOString(); }

app.use(async (req,res,next)=>{
  try {
    await initializeDatabase();
    res.setHeader('X-Content-Type-Options','nosniff');
    if (req.path !== '/health') res.setHeader('Cache-Control','no-store');
    res.locals.appName='PAC Kamra Complaint System';
    res.locals.user=req.session.user || null;
    res.locals.flash=req.session.flash || null;
    delete req.session.flash;
    if(req.session.user) {
      const row = await db.prepare('SELECT COUNT(*) c FROM notifications WHERE user_id=? AND is_read=0').get(req.session.user.id);
      res.locals.unreadCount=row?.c || 0;
    } else res.locals.unreadCount=0;
    next();
  } catch (err) { next(err); }
});

function flash(req,type,msg){ req.session.flash={type,msg}; }
function currentUser(req){ return req.session.user; }
function requireAuth(req,res,next){ if(!currentUser(req)) return res.redirect('/login'); next(); }
function requireRole(...roles){ return (req,res,next)=> {
  const u=currentUser(req); if(!u) return res.redirect('/login');
  if(!roles.includes(u.role)) return res.status(403).render('error',{message:'You are not authorized to access this page.'});
  next();
};}
async function userById(id){ return (await db.prepare(`SELECT u.*,r.name role,f.name factory,t.name trade,ra.name rank
 FROM users u JOIN roles r ON r.id=u.role_id LEFT JOIN factories f ON f.id=u.factory_id
 LEFT JOIN trades t ON t.id=u.trade_id LEFT JOIN ranks ra ON ra.id=u.rank_id WHERE u.id=?`).get(id)); }
async function complaintById(id){
 return (await db.prepare(`SELECT c.*, ct.name type, f.name factory, ff.name forwarded_factory,
 u.full_name complainant, dr.name drop_reason, du.full_name dropped_by
 FROM complaints c JOIN complaint_types ct ON ct.id=c.complaint_type_id
 JOIN factories f ON f.id=c.factory_id JOIN users u ON u.id=c.user_id
 LEFT JOIN factories ff ON ff.id=c.forwarded_to_factory_id LEFT JOIN drop_reasons dr ON dr.id=c.drop_reason_id
 LEFT JOIN users du ON du.id=c.dropped_by WHERE c.id=?`).get(id));
}
async function roleId(name){ return (await db.prepare('SELECT id FROM roles WHERE name=?').get(name))?.id; }
async function factoryName(id){ return (await db.prepare('SELECT name FROM factories WHERE id=?').get(id))?.name; }
async function addNotification(userId,message,complaintId=null){ await db.prepare('INSERT INTO notifications(user_id,complaint_id,message,created_date) VALUES(?,?,?,?)').run(userId,complaintId,message,now()); }
async function notifyRole(role,factoryId,message,complaintId){
 let q=`SELECT u.id FROM users u JOIN roles r ON r.id=u.role_id WHERE r.name=? AND u.account_status='Approved'`;
 const args=[role]; if(factoryId){q+=' AND u.factory_id=?';args.push(factoryId);}
 const users=await db.prepare(q).all(...args); for(const u of users) await addNotification(u.id,message,complaintId);
}
async function audit(complaintId,by,action,details){ await db.prepare('INSERT INTO audit_logs(complaint_id,performed_by,action_type,action_details,timestamp) VALUES(?,?,?,?,?)').run(complaintId,by,action,details,now()); }
async function history(complaintId,by,field,oldVal,newVal,note){ await db.prepare('INSERT INTO complaint_history(complaint_id,changed_by,field_changed,old_value,new_value,note,change_date) VALUES(?,?,?,?,?,?,?)').run(complaintId,by,field,oldVal,newVal,note,now()); }
async function flow(cId,fromRole,fromFactory,toRole,toFactory,action,note,by){
 await db.prepare(`INSERT INTO forwarding_flows(complaint_id,from_role_id,from_factory_id,to_role_id,to_factory_id,action,note,performed_by,action_date)
 VALUES(?,?,?,?,?,?,?,?,?)`).run(cId,await roleId(fromRole),fromFactory,await roleId(toRole),toFactory,action,note,by,now());
}
async function setStage(id,stage,by,note){
 const c=await complaintById(id); await db.prepare('UPDATE complaints SET current_stage=?,last_action_date=? WHERE id=?').run(stage,now(),id);
 await history(id,by,'CurrentStage',c.current_stage,stage,note);
}
function dashboardFor(role){ return {Admin:'/admin',NormalUser:'/complaints',CHRO:'/chro',Level2_MD:'/md',HRM:'/hrm',FactorySection:'/section'}[role]||'/'; }
function pager(total,page,size){ const pages=Math.max(1,Math.ceil(total/size)); page=Math.min(Math.max(1,Number(page)||1),pages); return {page,pages,size,total}; }

app.get('/health',async (req,res)=>res.status(200).json({status:'ok',application:'PAC Kamra Complaint System',database:process.env.DATABASE_URL?'postgres':'not-configured',time:now()}));
app.use(async (req,res,next)=>{ try { await runAutoEscalation(); } catch (e) { console.error('Escalation check failed',e); } next(); });

app.get('/',async (req,res)=>res.render('home'));
app.get('/privacy',async (req,res)=>res.render('simple',{title:'Privacy Policy',body:'PAC Kamra Complaint System keeps complaint and account information for authorized system operations. Use strong passwords and do not share your credentials.'}));
app.get('/terms',async (req,res)=>res.render('simple',{title:'Terms & Conditions',body:'Use the PAC Kamra Complaint System only for legitimate workplace complaints. Provide accurate information and respect confidentiality.'}));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 100, standardHeaders: 'draft-8', legacyHeaders: false, message: 'Too many authentication requests. Please try again later.' });
app.get('/login',async (req,res)=>res.render('auth/login',{title:'Login'}));
app.post('/login', authLimiter, async (req,res)=>{
 const {username,password,rememberMe}=req.body;
 const u=await userById((await db.prepare('SELECT id FROM users WHERE username=?').get(username||''))?.id);
 if(!u || !bcrypt.compareSync(password||'',u.password_hash)) { flash(req,'error','Invalid username or password.'); return res.redirect('/login'); }
 if(u.account_status!=='Approved'){ flash(req,'error','This account is not active. Please contact the system administrator.'); return res.redirect('/login'); }
 req.session.user={id:u.id,fullName:u.full_name,username:u.username,role:u.role,factoryId:u.factory_id,factory:u.factory};
 if(rememberMe==='on') req.sessionOptions.maxAge=30*24*60*60*1000;
 res.redirect(dashboardFor(u.role));
});
app.get('/signup',async (req,res)=>res.render('auth/signup',{title:'Employee Registration',factories:(await db.prepare('SELECT * FROM factories WHERE active=1').all()),trades:(await db.prepare('SELECT * FROM trades WHERE active=1').all()),ranks:(await db.prepare('SELECT * FROM ranks WHERE active=1').all())}));
app.post('/signup', authLimiter, async (req,res)=>{
 const {fullName,username,password,confirmPassword,factoryId,tradeId,rankId}=req.body;
 if(!fullName||!username||!password||password!==confirmPassword){flash(req,'error','Please complete all fields and make sure passwords match.');return res.redirect('/signup');}
 if((await db.prepare('SELECT id FROM users WHERE username=?').get(username.trim()))){flash(req,'error','Username already exists.');return res.redirect('/signup');}
 const hash=bcrypt.hashSync(password,10), role=await roleId('NormalUser');
 (await db.prepare(`INSERT INTO users(full_name,username,password_hash,factory_id,trade_id,rank_id,role_id,account_status,registered_date)
 VALUES(?,?,?,?,?,?,?,'Approved',?)`).run(fullName.trim(),username.trim(),hash,Number(factoryId),Number(tradeId)||null,Number(rankId)||null,role,now()));
 flash(req,'success','Account created successfully. You can now log in without administrator approval.');
 res.redirect('/login');
});
app.post('/logout',requireAuth,async (req,res)=>{ req.session = null; res.redirect('/login'); });
app.get('/change-password',requireAuth,async (req,res)=>res.render('auth/change-password',{title:'Change Password'}));
app.post('/change-password',requireAuth,async (req,res)=>{
 const u=await userById(req.session.user.id),{currentPassword,newPassword,confirmNewPassword}=req.body;
 if(!bcrypt.compareSync(currentPassword||'',u.password_hash)||!newPassword||newPassword!==confirmNewPassword){flash(req,'error','Current password is incorrect or the new passwords do not match.');return res.redirect('/change-password');}
 (await db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(bcrypt.hashSync(newPassword,10),u.id)); flash(req,'success','Password changed successfully.');res.redirect(dashboardFor(u.role));
});

app.get('/complaints',requireRole('NormalUser'),async (req,res)=>{
 const u=currentUser(req),status=req.query.statusFilter||'',type=req.query.typeFilter||'',page=Number(req.query.page)||1,size=5;
 let where='c.user_id=?',args=[u.id]; if(status){where+=' AND c.status=?';args.push(status);} if(type){where+=' AND c.complaint_type_id=?';args.push(type);}
 const total=(await db.prepare(`SELECT COUNT(*) c FROM complaints c WHERE ${where}`).get(...args)).c,p=pager(total,page,size);
 const rows=(await db.prepare(`SELECT c.*,ct.name type,f.name factory FROM complaints c JOIN complaint_types ct ON ct.id=c.complaint_type_id JOIN factories f ON f.id=c.factory_id WHERE ${where} ORDER BY c.submitted_date DESC LIMIT ? OFFSET ?`).all(...args,p.size,(p.page-1)*p.size));
 res.render('complaints/index',{title:'My Complaints',rows,p,status,type,types:(await db.prepare('SELECT * FROM complaint_types WHERE active=1').all())});
});
app.get('/complaints/submit',requireRole('NormalUser'),async (req,res)=>res.render('complaints/submit',{title:'Submit a Complaint',types:(await db.prepare('SELECT * FROM complaint_types WHERE active=1').all())}));
app.post('/complaints/submit',requireRole('NormalUser'),async (req,res)=>{
 const u=currentUser(req),{complaintTypeId,description,isAnonymous}=req.body;
 if(!complaintTypeId||!description?.trim()){flash(req,'error','Complaint type and description are required.');return res.redirect('/complaints/submit');}
 const factoryId=u.factoryId;
 const dup=(await db.prepare(`SELECT * FROM complaints WHERE user_id=? AND factory_id=? AND complaint_type_id=? AND lower(trim(description))=lower(trim(?)) AND status IN ('Resolved','Closed') ORDER BY id DESC LIMIT 1`).get(u.id,factoryId,complaintTypeId,description.trim()));
 const r=(await db.prepare(`INSERT INTO complaints(user_id,factory_id,complaint_type_id,description,anonymous,status,current_level,submitted_date,last_action_date,current_stage)
  VALUES(?,?,?,?,?,'InProcess',1,?,?, 'CHRO')`).run(u.id,factoryId,complaintTypeId,description.trim(),isAnonymous==='on'?1:0,now(),now()));
 const id=r.lastInsertRowid;
 await audit(id,u.id,'Submitted','Complaint submitted and forwarded to CHRO for review.');
 await addNotification(u.id,`Your complaint (#${id}) has been submitted and forwarded to CHRO for review.`,id);
 await notifyRole('CHRO',null,`New complaint (#${id}) has been submitted and requires your review.`,id);
 if(dup){await db.prepare('INSERT INTO duplicate_flags(original_complaint_id,duplicate_complaint_id,flagged_level,created_date) VALUES(?,?,?,?)').run(dup.id,id,1,now());await db.prepare(`UPDATE complaints SET status='Dropped',current_stage='Closed',other_drop_reason=?,last_action_date=? WHERE id=?`).run('Duplicate of complaint #'+dup.id,now(),id);await addNotification(u.id,`Complaint #${id} was identified as a duplicate of complaint #${dup.id} and dropped.`,id);} flash(req,'success',`Complaint submitted successfully. Reference number: #${id}`);res.redirect('/complaints');
});
app.get('/complaints/search',requireAuth,async (req,res)=>{
 const u=currentUser(req),term=(req.query.q||'').trim(),page=Number(req.query.page)||1,size=10;
 if(u.role==='NormalUser') return res.redirect('/complaints');
 let where='1=1',args=[];
 if(u.role==='Level2_MD'){where+=' AND c.forwarded_to_factory_id=?';args.push(u.factoryId);}
 if(u.role==='HRM'||u.role==='FactorySection'){where+=' AND (c.factory_id=? OR c.forwarded_to_factory_id=?)';args.push(u.factoryId,u.factoryId);}
 if(term){if(/^\d+$/.test(term)){where+=' AND (c.id=? OR c.description LIKE ?)';args.push(Number(term),`%${term}%`);}else{where+=' AND (c.description LIKE ? OR u.full_name LIKE ?)';args.push(`%${term}%`,`%${term}%`);}}
 const total=(await db.prepare(`SELECT COUNT(*) c FROM complaints c JOIN users u ON u.id=c.user_id WHERE ${where}`).get(...args)).c,p=pager(total,page,size);
 const rows=term?(await db.prepare(`SELECT c.*,ct.name type,f.name factory,u.full_name complainant FROM complaints c JOIN complaint_types ct ON ct.id=c.complaint_type_id JOIN factories f ON f.id=c.factory_id JOIN users u ON u.id=c.user_id WHERE ${where} ORDER BY c.submitted_date DESC LIMIT ? OFFSET ?`).all(...args,p.size,(p.page-1)*p.size)):[];
 res.render('complaints/search',{title:'Complaint Search',rows,p,q:term});
});
app.get('/complaints/:id',requireAuth,async (req,res)=>{
 const c=await complaintById(Number(req.params.id)); if(!c||!ensureScope(req,c))return res.status(403).render('error',{message:'You are not authorized to view this complaint.'});
 const historyRows=(await db.prepare(`SELECT h.*,u.full_name actor FROM complaint_history h LEFT JOIN users u ON u.id=h.changed_by WHERE h.complaint_id=? ORDER BY h.change_date`).all(c.id));
 const flows=(await db.prepare(`SELECT f.*,fr.name from_role,tr.name to_role,ff.name from_factory,tf.name to_factory,u.full_name actor FROM forwarding_flows f LEFT JOIN roles fr ON fr.id=f.from_role_id LEFT JOIN roles tr ON tr.id=f.to_role_id LEFT JOIN factories ff ON ff.id=f.from_factory_id LEFT JOIN factories tf ON tf.id=f.to_factory_id LEFT JOIN users u ON u.id=f.performed_by WHERE f.complaint_id=? ORDER BY f.action_date`).all(c.id));
 const esc=(await db.prepare('SELECT * FROM escalation_logs WHERE complaint_id=? ORDER BY escalated_date').all(c.id));
 const sat=(await db.prepare('SELECT * FROM satisfaction_responses WHERE complaint_id=?').get(c.id));
 res.render('complaints/details',{title:`Complaint #${c.id}`,c,historyRows,flows,esc,sat,showName:currentUser(req).role!=='NormalUser'});
});
app.post('/complaints/:id/withdraw',requireRole('NormalUser'),async (req,res)=>{
 const c=await complaintById(Number(req.params.id)),u=currentUser(req);if(!c||c.user_id!==u.id)return res.sendStatus(404);
 if(['Resolved','Dropped','Closed'].includes(c.status)){flash(req,'error','This complaint can no longer be withdrawn.');return res.redirect('/complaints');}
 (await db.prepare(`UPDATE complaints SET withdrawn=1,status='Closed',current_stage='Closed',last_action_date=? WHERE id=?`).run(now(),c.id));
 await audit(c.id,u.id,'Withdrawn','Complaint withdrawn by complainant.');await notifyRole('CHRO',null,`Complaint #${c.id} was withdrawn by the complainant.`,c.id);
 flash(req,'success',`Complaint #${c.id} withdrawn.`);res.redirect('/complaints');
});
app.get('/complaints/:id/download',requireRole('NormalUser'),async (req,res)=>{
 const c=await complaintById(Number(req.params.id)),u=currentUser(req);if(!c||c.user_id!==u.id)return res.sendStatus(404);
 const esc=(await db.prepare('SELECT * FROM escalation_logs WHERE complaint_id=?').all(c.id));
 const hist=(await db.prepare('SELECT h.*,u.full_name actor FROM complaint_history h LEFT JOIN users u ON u.id=h.changed_by WHERE h.complaint_id=?').all(c.id));
 const flows=(await db.prepare('SELECT f.*,u.full_name actor FROM forwarding_flows f LEFT JOIN users u ON u.id=f.performed_by WHERE f.complaint_id=?').all(c.id));
 let text=`PAC KAMRA COMPLAINT SYSTEM - COMPLAINT SUMMARY\n========================================\nReference: #${c.id}\nFactory: ${c.factory}\nType: ${c.type}\nDescription: ${c.description}\nStatus: ${c.status}\nCurrent Level: ${c.current_level}\nCurrent Stage: ${c.current_stage}\nAnonymous: ${c.anonymous?'Yes':'No'}\nWithdrawn: ${c.withdrawn?'Yes':'No'}\nSubmitted: ${c.submitted_date}\nLast Action: ${c.last_action_date}\n`;
 if(c.resolution_note)text+=`Resolution Note: ${c.resolution_note}\n`; if(c.drop_reason)text+=`Drop Reason: ${c.drop_reason==='Other'?c.other_drop_reason:c.drop_reason}\n`;
 text+=`\nESCALATION HISTORY\n`; text+=esc.length?esc.map(e=>`${e.escalated_date}: Level ${e.from_level} -> ${e.to_level} (${e.reason_text||''})`).join('\n'):'(none)';
 text+=`\n\nHISTORY\n`; text+=hist.length?hist.map(h=>`${h.change_date}: ${h.actor||'System'} | ${h.field_changed}: ${h.old_value} -> ${h.new_value} | ${h.note||''}`).join('\n'):'(none)';
 text+=`\n\nFORWARDING FLOW\n`; text+=flows.length?flows.map(f=>`${f.action_date}: ${f.actor||'System'} | ${f.action} | ${f.note||''}`).join('\n'):'(none)';
 res.setHeader('Content-Type','text/plain');res.setHeader('Content-Disposition',`attachment; filename=PAC-Complaint-${c.id}.txt`);res.send(text);
});
app.get('/complaints/:id/satisfaction',requireRole('NormalUser'),async (req,res)=>{const c=await complaintById(Number(req.params.id));if(!c||c.user_id!==currentUser(req).id)return res.sendStatus(404);res.render('complaints/satisfaction',{title:`Satisfaction - #${c.id}`,c});});
app.post('/complaints/:id/satisfaction',requireRole('NormalUser'),async (req,res)=>{
 const c=await complaintById(Number(req.params.id));if(!c||c.user_id!==currentUser(req).id)return res.sendStatus(404);
 (await db.prepare('INSERT INTO satisfaction_responses(complaint_id,is_satisfied,responded_date) VALUES(?,?,?) ON CONFLICT(complaint_id) DO UPDATE SET is_satisfied=excluded.is_satisfied,responded_date=excluded.responded_date').run(c.id,req.body.isSatisfied==='true'?1:0,now()));
 if(req.body.isSatisfied==='true') (await db.prepare(`UPDATE complaints SET status='Closed',current_stage='Closed',last_action_date=? WHERE id=? AND status='Resolved'`).run(now(),c.id));
 await addNotification(c.user_id,`Satisfaction response recorded for complaint #${c.id}.`,c.id);flash(req,'success','Your satisfaction response was recorded.');res.redirect('/complaints/'+c.id);
});


function workingDaysBetween(startIso,endIso){
 const a=new Date(startIso),b=new Date(endIso);let count=0,d=new Date(a);
 d.setHours(0,0,0,0); const end=new Date(b);end.setHours(0,0,0,0);
 while(d<end){d.setDate(d.getDate()+1);const day=d.getDay();if(day!==0&&day!==6)count++;}
 return count;
}
async function runAutoEscalation(){
 const active=(await db.prepare(`SELECT * FROM complaints WHERE status IN ('InProcess','Reopened')`).all());
 for (const c of active) {
   const days=workingDaysBetween(c.submitted_date,new Date().toISOString());
   let to=null,target=null,reason='';
   if(c.current_stage==='CHRO'&&!c.forwarded_to_factory_id&&days>=21){to='MD';target=c.factory_id;reason=`CHRO did not act within 21 working days (elapsed: ${days}). Auto-forwarded to MD of the concerned factory.`;}
   else if(c.current_stage==='MD'&&c.forwarded_to_factory_id&&days>=41){to='HRM';target=c.forwarded_to_factory_id;reason=`MD did not act within 41 working days (elapsed: ${days}). Auto-escalated to HRM.`;}
   else if(c.current_stage==='HRM'&&c.forwarded_to_factory_id&&days>=61){to='Section';target=c.forwarded_to_factory_id;reason=`HRM did not act within 61 working days (elapsed: ${days}). Auto-escalated to Section.`;}
   if(!to)return;
   const from=c.current_stage, fromRole=from==='CHRO'?'CHRO':from==='MD'?'Level2_MD':'HRM', toRole=to==='MD'?'Level2_MD':to==='HRM'?'HRM':'FactorySection';
   (await db.prepare('UPDATE complaints SET current_stage=?,forwarded_to_factory_id=?,last_action_date=? WHERE id=?').run(to,target,now(),c.id));
   await flow(c.id,fromRole,from==='CHRO'?null:c.forwarded_to_factory_id,toRole,target,'AutoEscalated',reason,null);
   await history(c.id,null,'CurrentStage',from,to,reason);
   await audit(c.id,null,'AutoEscalated',reason);
   await notifyRole(toRole,target,`Complaint #${c.id} has auto-escalated to your level. ${reason}`,c.id);
   await addNotification(c.user_id,`Your complaint (#${c.id}) was automatically escalated. ${reason}`,c.id);
 }
}

async function roleDashboard(req,res,role,view){
 const u=currentUser(req),page=Number(req.query.page)||1,size=5;let where=`c.current_stage=? AND c.status IN ('InProcess','Reopened')`,args=[role==='CHRO'?'CHRO':role==='Level2_MD'?'MD':role==='HRM'?'HRM':'Section'];
 if(role==='CHRO'&&req.query.factoryFilter){where+=' AND c.factory_id=?';args.push(Number(req.query.factoryFilter));}
 if(role==='Level2_MD'){where='c.forwarded_to_factory_id=? AND c.current_stage="MD" AND c.status IN ("InProcess","Reopened")';args=[u.factoryId];}
 if(role==='HRM'){where='c.factory_id=? AND c.current_stage="HRM" AND c.status IN ("InProcess","Reopened")';args=[u.factoryId];}
 if(role==='FactorySection'){where='c.forwarded_to_factory_id=? AND c.current_stage="Section" AND c.status IN ("InProcess","Reopened")';args=[u.factoryId];}
 const total=(await db.prepare(`SELECT COUNT(*) c FROM complaints c WHERE ${where}`).get(...args)).c,p=pager(total,page,size);
 const rows=(await db.prepare(`SELECT c.*,ct.name type,u.full_name complainant,f.name factory FROM complaints c JOIN complaint_types ct ON ct.id=c.complaint_type_id JOIN users u ON u.id=c.user_id JOIN factories f ON f.id=c.factory_id WHERE ${where} ORDER BY c.submitted_date LIMIT ? OFFSET ?`).all(...args,p.size,(p.page-1)*p.size));
 res.render(view,{title:`${role} Dashboard`,rows,p,role,factory:u.factory,dropReasons:(await db.prepare('SELECT * FROM drop_reasons WHERE active=1').all()),factories:(await db.prepare('SELECT * FROM factories WHERE active=1').all()),types:(await db.prepare('SELECT * FROM complaint_types WHERE active=1').all())});
}
app.get('/chro',requireRole('CHRO'),async (req,res)=>await roleDashboard(req,res,'CHRO','dashboards/queue'));
app.get('/md',requireRole('Level2_MD'),async (req,res)=>await roleDashboard(req,res,'Level2_MD','dashboards/queue'));
app.get('/hrm',requireRole('HRM'),async (req,res)=>await roleDashboard(req,res,'HRM','dashboards/queue'));
app.get('/section',requireRole('FactorySection'),async (req,res)=>await roleDashboard(req,res,'FactorySection','dashboards/queue'));

function action(req,res,role,handler){ if(!currentUser(req)||currentUser(req).role!==role)return res.redirect('/login'); try{handler();}catch(e){console.error(e);flash(req,'error','Action could not be completed.');} res.redirect(dashboardFor(role));}
app.post('/chro/forward',requireRole('CHRO'),async (req,res)=>{
 const u=currentUser(req),id=Number(req.body.complaintId),target=Number(req.body.targetFactoryId),c=await complaintById(id),f=await factoryName(target);if(!c||!target){flash(req,'error','Select a target factory.');return res.redirect('/chro');}
 if(c.current_stage!=='CHRO'||!['InProcess','Reopened'].includes(c.status)){flash(req,'error','This complaint is no longer in the CHRO queue.');return res.redirect('/chro');}
 (await db.prepare('UPDATE complaints SET current_stage="MD",forwarded_to_factory_id=?,last_action_date=? WHERE id=?').run(target,now(),id));
 await flow(id,'CHRO',null,'Level2_MD',target,'Forwarded',req.body.forwardNote||'Forwarded by CHRO to MD for review.',u.id);await history(id,u.id,'CurrentStage','CHRO','MD',`Forwarded to ${f} MD.`);await audit(id,u.id,'Forwarded',`CHRO forwarded complaint to ${f} MD.`);
 await notifyRole('Level2_MD',target,`Complaint #${id} has been forwarded to you by CHRO for review.`,id);await addNotification(c.user_id,`Your complaint (#${id}) has been forwarded to ${f} MD for review.`,id);flash(req,'success',`Complaint #${id} forwarded to ${f} MD.`);res.redirect('/chro');
});
app.post('/chro/drop',requireRole('CHRO'),async (req,res)=>await doDrop(req,res,'CHRO','CHRO',null));
app.post('/md/approve',requireRole('Level2_MD'),async (req,res)=>{
 const u=currentUser(req),id=Number(req.body.complaintId),c=await complaintById(id);if(!c||c.forwarded_to_factory_id!==u.factoryId||c.current_stage!=='MD'||!['InProcess','Reopened'].includes(c.status))return res.sendStatus(403);
 (await db.prepare('UPDATE complaints SET current_stage="HRM",last_action_date=? WHERE id=?').run(now(),id));await flow(id,'Level2_MD',u.factoryId,'HRM',u.factoryId,'Approved',req.body.approveNote||'Approved by MD and forwarded to HRM.',u.id);await history(id,u.id,'CurrentStage','MD','HRM','MD approved forwarding to HRM.');await notifyRole('HRM',u.factoryId,`Complaint #${id} was approved by MD and forwarded to you.`,id);await addNotification(c.user_id,`Your complaint (#${id}) has been approved by MD and forwarded to HRM.`,id);await audit(id,u.id,'Approved','MD approved complaint and forwarded to HRM.');flash(req,'success',`Complaint #${id} approved.`);res.redirect('/md');
});
app.post('/md/reverse',requireRole('Level2_MD'),async (req,res)=>{const u=currentUser(req),id=Number(req.body.complaintId),c=await complaintById(id);if(!c||c.forwarded_to_factory_id!==u.factoryId||c.current_stage!=='MD'||!['InProcess','Reopened'].includes(c.status))return res.sendStatus(403);const note=(req.body.reverseReason||'').trim();if(!note){flash(req,'error','Reason is required.');return res.redirect('/md');}(await db.prepare(`UPDATE complaints SET status='InProcess',current_stage='CHRO',forwarded_to_factory_id=NULL,other_drop_reason=NULL,last_action_date=? WHERE id=?`).run(now(),id));await flow(id,'Level2_MD',u.factoryId,'CHRO',null,'Reversed',note,u.id);await history(id,u.id,'CurrentStage','MD','CHRO',`Returned to CHRO by MD. ${note}`);await notifyRole('CHRO',null,`Complaint #${id} was reversed by MD. Reason: ${note}`,id);await addNotification(c.user_id,`Your complaint (#${id}) was returned by MD. Reason: ${note}`,id);await audit(id,u.id,'Reversed',note);flash(req,'success',`Complaint #${id} returned to CHRO.`);res.redirect('/md');});
app.post('/md/resolve',requireRole('Level2_MD'),async (req,res)=>await doResolve(req,res,'Level2_MD'));
app.post('/md/drop',requireRole('Level2_MD'),async (req,res)=>await doDrop(req,res,'Level2_MD','Level2_MD',currentUser(req).factoryId));

app.post('/hrm/forward',requireRole('HRM'),async (req,res)=>{const u=currentUser(req),id=Number(req.body.complaintId),c=await complaintById(id);if(!c||c.factory_id!==u.factoryId||c.current_stage!=='HRM'||!['InProcess','Reopened'].includes(c.status))return res.sendStatus(403);(await db.prepare('UPDATE complaints SET current_stage="Section",last_action_date=? WHERE id=?').run(now(),id));await flow(id,'HRM',u.factoryId,'FactorySection',u.factoryId,'Forwarded',req.body.forwardNote||'Forwarded to concerned Section.',u.id);await history(id,u.id,'CurrentStage','HRM','Section','Forwarded by HRM to Section.');await notifyRole('FactorySection',u.factoryId,`Complaint #${id} has been forwarded to your Section by HRM.`,id);await addNotification(c.user_id,`Your complaint (#${id}) has been forwarded to the concerned Section by HRM.`,id);await audit(id,u.id,'Forwarded','HRM forwarded complaint to Section.');flash(req,'success',`Complaint #${id} forwarded to Section.`);res.redirect('/hrm');});
app.post('/hrm/resolve',requireRole('HRM'),async (req,res)=>await doResolve(req,res,'HRM'));
app.post('/hrm/drop',requireRole('HRM'),async (req,res)=>await doDrop(req,res,'HRM','HRM',currentUser(req).factoryId));
app.post('/section/resolve',requireRole('FactorySection'),async (req,res)=>await doResolve(req,res,'FactorySection'));
app.post('/section/drop',requireRole('FactorySection'),async (req,res)=>await doDrop(req,res,'FactorySection','FactorySection',currentUser(req).factoryId));

async function doResolve(req,res,role){
 const u=currentUser(req),id=Number(req.body.complaintId),note=(req.body.resolutionNote||'').trim(),c=await complaintById(id);if(!c||!note){flash(req,'error','Resolution note is required.');return res.redirect(dashboardFor(role));}
 const valid=(['InProcess','Reopened'].includes(c.status)) && (role==='CHRO'?c.current_stage==='CHRO':role==='Level2_MD'?c.forwarded_to_factory_id===u.factoryId&&c.current_stage==='MD':role==='HRM'?c.factory_id===u.factoryId&&c.current_stage==='HRM':c.forwarded_to_factory_id===u.factoryId&&c.current_stage==='Section');if(!valid)return res.sendStatus(403);
 (await db.prepare(`UPDATE complaints SET status='Resolved',current_stage='Closed',resolved_date=?,last_action_date=?,resolution_note=? WHERE id=?`).run(now(),now(),note,id));
 await flow(id,role,u.factoryId,role,u.factoryId,'Resolved',note,u.id);await history(id,u.id,'Status','InProcess','Resolved',`Resolved by ${role}. ${note}`);await audit(id,u.id,'Resolved',note);
 await addNotification(c.user_id,`Your complaint (#${id}) has been resolved by ${role}. Resolution: ${note} Please confirm if you are satisfied.`,id);
 if(role==='FactorySection'){await notifyRole('HRM',u.factoryId,`Complaint #${id} was resolved by Section and reported back.`,id);await notifyRole('Level2_MD',u.factoryId,`Complaint #${id} was resolved by Section and reported back.`,id);await notifyRole('CHRO',null,`Complaint #${id} was resolved by Section and reported back.`,id);}
 else if(role==='Level2_MD'){await notifyRole('HRM',u.factoryId,`Complaint #${id} was resolved directly by MD.`,id);await notifyRole('CHRO',null,`Complaint #${id} was resolved directly by MD.`,id);}
 else if(role==='HRM')await notifyRole('CHRO',null,`Complaint #${id} was resolved directly by HRM.`,id);
 flash(req,'success',`Complaint #${id} resolved.`);res.redirect(dashboardFor(role));
}
async function doDrop(req,res,role,fromRole,fromFactory){
 const u=currentUser(req),id=Number(req.body.complaintId),reasonId=Number(req.body.dropReasonId),other=(req.body.otherReasonText||'').trim(),c=await complaintById(id),r=(await db.prepare('SELECT * FROM drop_reasons WHERE id=?').get(reasonId));if(!c||!r){flash(req,'error','Please select a drop reason.');return res.redirect(dashboardFor(role));}
 const stageOk=role==='CHRO'?c.current_stage==='CHRO':role==='Level2_MD'?c.current_stage==='MD'&&c.forwarded_to_factory_id===u.factoryId:role==='HRM'?c.current_stage==='HRM'&&c.factory_id===u.factoryId:c.current_stage==='Section'&&c.forwarded_to_factory_id===u.factoryId;
 if(!stageOk||!['InProcess','Reopened'].includes(c.status)) return res.sendStatus(403);
 if(r.name==='Other'&&!other){flash(req,'error','Please specify the reason for Other.');return res.redirect(dashboardFor(role));}
 const displayed=r.name==='Other'?other:r.name;
 (await db.prepare(`UPDATE complaints SET status='Dropped',current_stage='Closed',drop_reason_id=?,dropped_by=?,other_drop_reason=?,last_action_date=? WHERE id=?`).run(reasonId,u.id,r.name==='Other'?other:null,now(),id));
 await flow(id,fromRole,fromFactory,fromRole,fromFactory,'Dropped',displayed,u.id);await history(id,u.id,'Status',c.status,'Dropped',`Dropped by ${role}. Reason: ${displayed}`);await audit(id,u.id,'Dropped',displayed);await addNotification(c.user_id,`Your complaint (#${id}) has been dropped. Reason: ${displayed}`,id);await notifyRole('CHRO',null,`Complaint #${id} was dropped by ${role}. Reason: ${displayed}`,id);flash(req,'success',`Complaint #${id} dropped.`);res.redirect(dashboardFor(role));
}


app.get('/hrm/monitor',requireRole('HRM'),async (req,res)=>{
 const u=currentUser(req),status=req.query.statusFilter||'',level=req.query.levelFilter||'',page=Number(req.query.page)||1,size=10;
 let where='c.factory_id=?',args=[u.factoryId]; if(status){where+=' AND c.status=?';args.push(status)} if(level){where+=' AND c.current_level=?';args.push(Number(level))}
 const total=(await db.prepare(`SELECT COUNT(*) c FROM complaints c WHERE ${where}`).get(...args)).c,p=pager(total,page,size);
 const rows=(await db.prepare(`SELECT c.*,ct.name type,u.full_name complainant,f.name factory FROM complaints c JOIN complaint_types ct ON ct.id=c.complaint_type_id JOIN users u ON u.id=c.user_id JOIN factories f ON f.id=c.factory_id WHERE ${where} ORDER BY c.submitted_date DESC LIMIT ? OFFSET ?`).all(...args,p.size,(p.page-1)*p.size));
 const duplicates=(await db.prepare(`SELECT d.*,u.full_name complainant FROM duplicate_flags d JOIN complaints c ON c.id=d.original_complaint_id JOIN users u ON u.id=c.user_id WHERE c.factory_id=? ORDER BY d.created_date DESC LIMIT 20`).all(u.factoryId));
 const escalations=(await db.prepare(`SELECT e.*,c.id complaint_id FROM escalation_logs e JOIN complaints c ON c.id=e.complaint_id WHERE c.factory_id=? ORDER BY e.escalated_date DESC LIMIT 20`).all(u.factoryId));
 res.render('admin/monitor',{title:'HRM Monitoring',rows,p,duplicates,escalations,status,level});
});
app.get('/hrm/export',requireRole('HRM'),async (req,res)=>{
 const u=currentUser(req);
 const rows=(await db.prepare(`SELECT c.id,c.anonymous,u.full_name complainant,f.name factory,ct.name type,c.description,c.status,c.current_level,c.current_stage,ff.name forwarded_factory,c.submitted_date,c.last_action_date,c.resolved_date,dr.name drop_reason,c.other_drop_reason,c.resolution_note,c.parent_complaint_id,c.withdrawn
 FROM complaints c JOIN users u ON u.id=c.user_id JOIN factories f ON f.id=c.factory_id JOIN complaint_types ct ON ct.id=c.complaint_type_id
 LEFT JOIN factories ff ON ff.id=c.forwarded_to_factory_id LEFT JOIN drop_reasons dr ON dr.id=c.drop_reason_id WHERE c.factory_id=? ORDER BY c.id`).all(u.factoryId));
 const esc=v=>{v=v==null?'':String(v);return /[",\n\r]/.test(v)?`"${v.replace(/"/g,'""')}"`:v};
 const header=['ComplaintId','Complainant','IsAnonymous','Factory','ComplaintType','Description','Status','CurrentLevel','CurrentStage','ForwardedToFactory','SubmittedDate','LastActionDate','ResolvedDate','DropReason','OtherDropReasonText','ResolutionNote','ParentComplaintId','IsWithdrawn'];
 const lines=[header.join(',')];rows.forEach(c=>lines.push([c.id,c.anonymous?'Anonymous':c.complainant,c.anonymous?'Yes':'No',c.factory,c.type,c.description,c.status,c.current_level,c.current_stage,c.forwarded_factory,c.submitted_date,c.last_action_date,c.resolved_date,c.drop_reason,c.other_drop_reason,c.resolution_note,c.parent_complaint_id,c.withdrawn?'Yes':'No'].map(esc).join(',')));
 res.setHeader('Content-Type','text/csv');res.setHeader('Content-Disposition',`attachment; filename=PAC-Complaints-${u.factory||u.factoryId}.csv`);res.send(lines.join('\n'));
});
app.get('/hrm/queue',requireRole('HRM'),async (req,res)=>res.redirect('/hrm'));

app.get('/actions',requireAuth,async (req,res)=>{
 const u=currentUser(req);if(u.role==='NormalUser'||u.role==='Admin')return res.redirect(dashboardFor(u.role));
 const page=Number(req.query.page)||1,size=10,total=(await db.prepare('SELECT COUNT(*) c FROM forwarding_flows WHERE performed_by=?').get(u.id)).c,p=pager(total,page,size);
 const rows=(await db.prepare(`SELECT f.*,c.id complaint_id,tr.name to_role,tf.name to_factory FROM forwarding_flows f JOIN complaints c ON c.id=f.complaint_id LEFT JOIN roles tr ON tr.id=f.to_role_id LEFT JOIN factories tf ON tf.id=f.to_factory_id WHERE f.performed_by=? ORDER BY f.action_date DESC LIMIT ? OFFSET ?`).all(u.id,p.size,(p.page-1)*p.size));
 res.render('dashboards/actions',{title:'My Action History',rows,p});
});

app.get('/notifications',requireAuth,async (req,res)=>{
 const u=currentUser(req),page=Number(req.query.page)||1,size=10,total=(await db.prepare('SELECT COUNT(*) c FROM notifications WHERE user_id=?').get(u.id)).c,p=pager(total,page,size);
 const rows=(await db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_date DESC LIMIT ? OFFSET ?').all(u.id,p.size,(p.page-1)*p.size));
 (await db.prepare('UPDATE notifications SET is_read=1 WHERE user_id=?').run(u.id));
 res.render('notifications/index',{title:'Notifications',rows,p});
});
app.post('/notifications/delete/:id',requireAuth,async (req,res)=>{(await db.prepare('DELETE FROM notifications WHERE id=? AND user_id=?').run(Number(req.params.id),currentUser(req).id));res.redirect('/notifications');});
app.post('/notifications/delete-all',requireAuth,async (req,res)=>{(await db.prepare('DELETE FROM notifications WHERE user_id=?').run(currentUser(req).id));res.redirect('/notifications');});

app.get('/admin',requireRole('Admin'),async (req,res)=>{
 const stats={
 active:(await db.prepare(`SELECT COUNT(*) c FROM users WHERE account_status='Approved'`).get()).c,
 users:(await db.prepare('SELECT COUNT(*) c FROM users').get()).c,
 complaints:(await db.prepare('SELECT COUNT(*) c FROM complaints').get()).c,
 open:(await db.prepare(`SELECT COUNT(*) c FROM complaints WHERE status IN ('InProcess','Reopened','New')`).get()).c,
 resolved:(await db.prepare(`SELECT COUNT(*) c FROM complaints WHERE status IN ('Resolved','Closed')`).get()).c,
 dropped:(await db.prepare(`SELECT COUNT(*) c FROM complaints WHERE status='Dropped'`).get()).c
 };
 const recent=(await db.prepare(`SELECT c.*,ct.name type,f.name factory FROM complaints c JOIN complaint_types ct ON ct.id=c.complaint_type_id JOIN factories f ON f.id=c.factory_id ORDER BY c.submitted_date DESC LIMIT 8`).all());
 const byFactory=(await db.prepare('SELECT f.name,COUNT(c.id) count FROM factories f LEFT JOIN complaints c ON c.factory_id=f.id GROUP BY f.id ORDER BY count DESC').all());
 res.render('admin/dashboard',{title:'Admin Dashboard',stats,recent,byFactory});
});
app.get('/admin/users',requireRole('Admin'),async (req,res)=>{
 const status=req.query.status||'',page=Number(req.query.page)||1,size=10;let where='1=1',args=[];if(status){where+=' AND u.account_status=?';args.push(status);}
 const total=(await db.prepare(`SELECT COUNT(*) c FROM users u WHERE ${where}`).get(...args)).c,p=pager(total,page,size);
 const rows=(await db.prepare(`SELECT u.*,r.name role,f.name factory,t.name trade,ra.name rank FROM users u JOIN roles r ON r.id=u.role_id LEFT JOIN factories f ON f.id=u.factory_id LEFT JOIN trades t ON t.id=u.trade_id LEFT JOIN ranks ra ON ra.id=u.rank_id WHERE ${where} ORDER BY u.registered_date DESC LIMIT ? OFFSET ?`).all(...args,p.size,(p.page-1)*p.size));
 res.render('admin/users',{title:'Manage Users',rows,p,status});
});

app.get('/admin/lookups',requireRole('Admin'),async (req,res)=>res.render('admin/lookups',{title:'Manage Lookups',factories:(await db.prepare('SELECT * FROM factories ORDER BY name').all()),types:(await db.prepare('SELECT * FROM complaint_types ORDER BY name').all()),reasons:(await db.prepare('SELECT * FROM drop_reasons ORDER BY name').all())}));
app.post('/admin/lookups/factory',requireRole('Admin'),async (req,res)=>{if(req.body.name?.trim())(await db.prepare('INSERT OR IGNORE INTO factories(name,active) VALUES(?,1)').run(req.body.name.trim()));res.redirect('/admin/lookups');});
app.post('/admin/lookups/type',requireRole('Admin'),async (req,res)=>{if(req.body.name?.trim())(await db.prepare('INSERT OR IGNORE INTO complaint_types(name,active) VALUES(?,1)').run(req.body.name.trim()));res.redirect('/admin/lookups');});
app.post('/admin/lookups/reason',requireRole('Admin'),async (req,res)=>{if(req.body.name?.trim())(await db.prepare('INSERT OR IGNORE INTO drop_reasons(name,active) VALUES(?,1)').run(req.body.name.trim()));res.redirect('/admin/lookups');});
app.post('/admin/lookups/:kind/:id/toggle',requireRole('Admin'),async (req,res)=>{
 const map={factory:'factories',type:'complaint_types',reason:'drop_reasons'},table=map[req.params.kind];if(table)(await db.prepare(`UPDATE ${table} SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?`).run(Number(req.params.id)));res.redirect('/admin/lookups');
});
app.get('/admin/audit',requireRole('Admin'),async (req,res)=>{
 const complaintId=Number(req.query.complaintId)||null,page=Number(req.query.page)||1,size=15;
 let where=complaintId?'WHERE a.complaint_id=?':'',args=complaintId?[complaintId]:[];
 const total=(await db.prepare(`SELECT COUNT(*) c FROM audit_logs a ${where}`).get(...args)).c,p=pager(total,page,size);
 const rows=(await db.prepare(`SELECT a.*,u.full_name actor FROM audit_logs a LEFT JOIN users u ON u.id=a.performed_by ${where} ORDER BY a.timestamp DESC LIMIT ? OFFSET ?`).all(...args,p.size,(p.page-1)*p.size));
 res.render('admin/audit',{title:'Audit Trail',rows,p,complaintId});
});
app.get('/admin/monitor',requireRole('Admin','HRM'),async (req,res)=>{
 const rows=(await db.prepare(`SELECT c.id,c.status,c.current_stage,c.current_level,c.submitted_date,ct.name type,f.name factory,u.full_name complainant
 FROM complaints c JOIN complaint_types ct ON ct.id=c.complaint_type_id JOIN factories f ON f.id=c.factory_id JOIN users u ON u.id=c.user_id
 ORDER BY c.last_action_date DESC LIMIT 100`).all());
 res.render('admin/monitor',{title:'Complaint Monitoring',rows});
});

app.use(async (req,res)=>res.status(404).render('error',{message:'Page not found.'}));
app.use((err,req,res,next)=>{console.error(err);res.status(500).render('error',{message:'An unexpected server error occurred.'});});

if (require.main === module) {
  initializeDatabase()
    .then(() => app.listen(PORT,()=>console.log(`PAC Kamra Complaint System running at http://localhost:${PORT}`)))
    .catch(err => { console.error('Database initialization failed:', err); process.exit(1); });
}

module.exports = app;
