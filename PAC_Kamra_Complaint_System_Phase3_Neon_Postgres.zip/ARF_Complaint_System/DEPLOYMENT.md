# PAC Kamra Complaint System — Phase 3 Deployment

This phase replaces the local SQLite database with PostgreSQL designed for Vercel + Neon.

## 1. Create the database

### Recommended: Vercel Marketplace

1. Sign in to Vercel.
2. Open your project.
3. Open **Storage / Marketplace** and add **Neon**.
4. Create a Neon Postgres resource.
5. Vercel will provide the database connection environment variables. Make sure `DATABASE_URL` is available to the project.

You can also provision it with the Vercel CLI:

```bash
npm i -g vercel
vercel login
vercel install neon
```

## 2. Deploy the web application

From the project root:

```bash
npm install
vercel
```

For a production deployment:

```bash
vercel --prod
```

Vercel detects the root `server.js` Express application.

## 3. Environment variables

Set these in Vercel Project Settings → Environment Variables:

```text
DATABASE_URL=your-neon-postgres-connection-string
SESSION_SECRET=a-long-random-secret
NODE_ENV=production
```

Never commit the real `.env` file or database password to GitHub.

## 4. Database initialization

On the first application request, `init-db.js` creates all PostgreSQL tables from `schema.sql` and creates the demo accounts.

Demo password:

```text
Admin@123
```

Change demo passwords before a real production rollout.

## 5. Local development

Create `.env` from `.env.example` and put your Neon `DATABASE_URL` in it.

Then:

```bash
npm install
npm start
```

Open:

```text
http://localhost:3000
```

## 6. Production checklist

- [ ] Use a strong unique `SESSION_SECRET`.
- [ ] Remove or change demo accounts/passwords.
- [ ] Configure the real PAC factories and roles.
- [ ] Review complaint retention/privacy rules with PAC administrators.
- [ ] Configure a custom domain in Vercel if required.
- [ ] Test every workflow: User → CHRO → MD → HRM → Section → Resolution.
- [ ] Test duplicate detection, escalation, notifications, audit history, reports, and satisfaction response.
- [ ] Create a database backup/recovery process.
- [ ] Restrict admin credentials and review audit logs regularly.
