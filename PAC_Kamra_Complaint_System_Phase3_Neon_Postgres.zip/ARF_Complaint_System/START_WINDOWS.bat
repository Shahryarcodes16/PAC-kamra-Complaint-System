@echo off
echo Installing PAC Kamra Complaint System...
call npm install
if errorlevel 1 pause & exit /b 1
echo.
echo Starting server at http://localhost:3000
call npm start
