const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { db } = require('./db');

let ready;
function now() { return new Date().toISOString(); }

async function initializeDatabase() {
  if (ready) return ready;
  ready = (async () => {
    const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
    await db.exec(schema);

    const addFactory = db.prepare('INSERT INTO factories(name,active) VALUES(?,1) ON CONFLICT(name) DO NOTHING');
    for (const x of ['ARF','MRF','AMF','APF']) await addFactory.run(x);
    const addRole = db.prepare('INSERT INTO roles(name,level_number) VALUES(?,?) ON CONFLICT(name) DO NOTHING');
    for (const x of [['Admin',0],['NormalUser',0],['CHRO',1],['Level2_MD',2],['HRM',3],['FactorySection',4]]) await addRole.run(...x);
    const addTrade = db.prepare('INSERT INTO trades(name,active) VALUES(?,1) ON CONFLICT(name) DO NOTHING');
    for (const x of ['Engineering','IT','Finance','HR','Operations']) await addTrade.run(x);
    const addRank = db.prepare('INSERT INTO ranks(name,active) VALUES(?,1) ON CONFLICT(name) DO NOTHING');
    for (const x of ['Officer','Assistant','Manager','Director']) await addRank.run(x);
    const addType = db.prepare('INSERT INTO complaint_types(name,active) VALUES(?,1) ON CONFLICT(name) DO NOTHING');
    for (const x of ['Administrative','HR','Technical','Safety','Facilities','Other']) await addType.run(x);
    const addReason = db.prepare('INSERT INTO drop_reasons(name,active) VALUES(?,1) ON CONFLICT(name) DO NOTHING');
    for (const x of ['Invalid Complaint','Duplicate','Out of Scope','Insufficient Information','Other']) await addReason.run(x);

    const role = async n => (await db.prepare('SELECT id FROM roles WHERE name=?').get(n)).id;
    const factory = async n => (await db.prepare('SELECT id FROM factories WHERE name=?').get(n)).id;
    const trade = (await db.prepare('SELECT id FROM trades LIMIT 1').get()).id;
    const rank = (await db.prepare('SELECT id FROM ranks LIMIT 1').get()).id;
    const insert = db.prepare(`INSERT INTO users
      (full_name,username,password_hash,factory_id,trade_id,rank_id,role_id,account_status,registered_date)
      VALUES(?,?,?,?,?,?,?,'Approved',?) ON CONFLICT(username) DO NOTHING`);
    const hash = bcrypt.hashSync('Admin@123', 10);
    await insert.run('System Administrator','admin',hash,null,trade,rank,await role('Admin'),now());
    await insert.run('Demo Employee','user',hash,await factory('ARF'),trade,rank,await role('NormalUser'),now());
    await insert.run('Chief HR Officer','chro',hash,null,trade,rank,await role('CHRO'),now());
    await insert.run('ARF Managing Director','md',hash,await factory('ARF'),trade,rank,await role('Level2_MD'),now());
    await insert.run('ARF HR Manager','hrm',hash,await factory('ARF'),trade,rank,await role('HRM'),now());
    await insert.run('ARF Section Officer','section',hash,await factory('ARF'),trade,rank,await role('FactorySection'),now());
  })();
  return ready;
}
module.exports = { initializeDatabase };
