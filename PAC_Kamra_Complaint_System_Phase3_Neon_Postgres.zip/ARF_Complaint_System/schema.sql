CREATE TABLE IF NOT EXISTS factories (id SERIAL PRIMARY KEY, name TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS roles (id SERIAL PRIMARY KEY, name TEXT NOT NULL UNIQUE, level_number INTEGER);
CREATE TABLE IF NOT EXISTS trades (id SERIAL PRIMARY KEY, name TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS ranks (id SERIAL PRIMARY KEY, name TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS complaint_types (id SERIAL PRIMARY KEY, name TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS drop_reasons (id SERIAL PRIMARY KEY, name TEXT NOT NULL UNIQUE, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY, full_name TEXT NOT NULL, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
  factory_id INTEGER, trade_id INTEGER, rank_id INTEGER, role_id INTEGER NOT NULL,
  account_status TEXT NOT NULL DEFAULT 'Approved', registered_date TEXT NOT NULL,
  approved_date TEXT, approved_by INTEGER,
  FOREIGN KEY(factory_id) REFERENCES factories(id), FOREIGN KEY(trade_id) REFERENCES trades(id),
  FOREIGN KEY(rank_id) REFERENCES ranks(id), FOREIGN KEY(role_id) REFERENCES roles(id), FOREIGN KEY(approved_by) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS complaints (
  id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL, factory_id INTEGER NOT NULL, complaint_type_id INTEGER NOT NULL,
  description TEXT NOT NULL, anonymous INTEGER NOT NULL DEFAULT 0, resolution_note TEXT,
  status TEXT NOT NULL DEFAULT 'InProcess', current_level INTEGER NOT NULL DEFAULT 1,
  submitted_date TEXT NOT NULL, last_action_date TEXT NOT NULL, resolved_date TEXT,
  drop_reason_id INTEGER, dropped_by INTEGER, parent_complaint_id INTEGER, withdrawn INTEGER NOT NULL DEFAULT 0,
  other_drop_reason TEXT, current_stage TEXT NOT NULL DEFAULT 'CHRO', forwarded_to_factory_id INTEGER,
  FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(factory_id) REFERENCES factories(id),
  FOREIGN KEY(complaint_type_id) REFERENCES complaint_types(id), FOREIGN KEY(drop_reason_id) REFERENCES drop_reasons(id),
  FOREIGN KEY(dropped_by) REFERENCES users(id), FOREIGN KEY(parent_complaint_id) REFERENCES complaints(id),
  FOREIGN KEY(forwarded_to_factory_id) REFERENCES factories(id)
);
CREATE TABLE IF NOT EXISTS audit_logs (id SERIAL PRIMARY KEY, complaint_id INTEGER, performed_by INTEGER, action_type TEXT NOT NULL, action_details TEXT, timestamp TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS complaint_history (id SERIAL PRIMARY KEY, complaint_id INTEGER NOT NULL, changed_by INTEGER, field_changed TEXT, old_value TEXT, new_value TEXT, note TEXT, change_date TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS forwarding_flows (id SERIAL PRIMARY KEY, complaint_id INTEGER NOT NULL, from_role_id INTEGER, from_factory_id INTEGER, to_role_id INTEGER, to_factory_id INTEGER, action TEXT NOT NULL, note TEXT, performed_by INTEGER, action_date TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS notifications (id SERIAL PRIMARY KEY, user_id INTEGER NOT NULL, complaint_id INTEGER, message TEXT NOT NULL, is_read INTEGER NOT NULL DEFAULT 0, created_date TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS satisfaction_responses (id SERIAL PRIMARY KEY, complaint_id INTEGER NOT NULL UNIQUE, is_satisfied INTEGER NOT NULL, responded_date TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS duplicate_flags (id SERIAL PRIMARY KEY, original_complaint_id INTEGER NOT NULL, duplicate_complaint_id INTEGER NOT NULL, flagged_level INTEGER, created_date TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS escalation_logs (id SERIAL PRIMARY KEY, complaint_id INTEGER NOT NULL, from_level INTEGER, to_level INTEGER, escalated_date TEXT NOT NULL, reason_text TEXT);
CREATE TABLE IF NOT EXISTS holiday_calendar (id SERIAL PRIMARY KEY, holiday_date TEXT NOT NULL UNIQUE, description TEXT);
