# PAC Kamra Complaint System

Professional JavaScript complaint management system for PAC Kamra.

## Stack

- Node.js 24
- Express 5
- EJS
- Neon PostgreSQL
- `@neondatabase/serverless`
- bcryptjs
- cookie-session
- Helmet
- Express Rate Limit
- Responsive/PWA frontend
- Expo React Native wrapper for Phase 2

## Main modules

- Employee signup/login without administrator approval
- Normal User dashboard
- CHRO dashboard
- MD dashboard
- HRM dashboard
- Factory Section dashboard
- Admin dashboard
- Complaint submission/search/details/history
- Complaint forwarding workflow
- Resolve/drop/reverse actions
- Notifications
- Audit trail
- Duplicate detection
- 21/41/61 working-day escalation
- HRM monitoring and CSV export
- Satisfaction response
- Complaint report download
- Password change
- PWA installation support
- Android wrapper in `mobile/`

## Demo accounts

All use `Admin@123`:

- `admin`
- `user`
- `chro`
- `md`
- `hrm`
- `section`

Change these before production use.

## Run locally

1. Create a Neon PostgreSQL database.
2. Copy `.env.example` to `.env`.
3. Set `DATABASE_URL` and a strong `SESSION_SECRET`.
4. Run:

```bash
npm install
npm start
```

5. Open `http://localhost:3000`.

## Deploy to Vercel

Read `DEPLOYMENT.md`.

Vercel supports Express deployments and Neon is available as a Vercel Marketplace Postgres integration.

## Phase 2 Android

After the website has a production URL, edit:

```text
mobile/App.js
```

and replace the placeholder web URL with the real Vercel URL. Then follow `mobile/README.md` to build an Android APK with Expo EAS.
